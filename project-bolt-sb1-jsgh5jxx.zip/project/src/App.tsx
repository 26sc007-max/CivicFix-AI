import { ChangeEvent, FormEvent, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  Bell,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Crosshair,
  FileText,
  Filter,
  ImagePlus,
  Layers3,
  MapPin,
  Menu,
  MoreHorizontal,
  Navigation,
  Plus,
  Radio,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  X,
  Zap,
} from 'lucide-react';

type Priority = 'High' | 'Medium' | 'Low';
type Status = 'Submitted' | 'In Progress' | 'Resolved';
type Category = 'Roads' | 'Waste' | 'Lighting' | 'Water' | 'Drainage';

type Complaint = {
  id: string;
  title: string;
  category: Category;
  location: string;
  priority: number;
  status: Status;
  created: string;
  reports: number;
  position: { top: string; left: string };
};

const initialComplaints: Complaint[] = [
  { id: '#CF-1042', title: 'Pothole', category: 'Roads', location: 'MG Road', priority: 92, status: 'In Progress', created: '15:39', reports: 6, position: { top: '30%', left: '47%' } },
  { id: '#CF-1041', title: 'Streetlight out', category: 'Lighting', location: '5th Avenue', priority: 74, status: 'Submitted', created: '15:34', reports: 3, position: { top: '22%', left: '67%' } },
  { id: '#CF-1040', title: 'Overflowing bin', category: 'Waste', location: 'Oak Street', priority: 61, status: 'Submitted', created: '15:27', reports: 4, position: { top: '53%', left: '29%' } },
  { id: '#CF-1039', title: 'Broken sidewalk', category: 'Roads', location: 'Elm Street', priority: 87, status: 'In Progress', created: '15:21', reports: 5, position: { top: '65%', left: '58%' } },
  { id: '#CF-1038', title: 'Water leakage', category: 'Water', location: 'Park Lane', priority: 45, status: 'Submitted', created: '15:18', reports: 2, position: { top: '42%', left: '77%' } },
  { id: '#CF-1037', title: 'Blocked drain', category: 'Drainage', location: 'River Road', priority: 81, status: 'Resolved', created: '14:56', reports: 7, position: { top: '76%', left: '38%' } },
];

const navItems = ['Dashboard', 'Incidents', 'Reports', 'Analytics', 'City Map'];
const categories: Category[] = ['Roads', 'Waste', 'Lighting', 'Water', 'Drainage'];

function priorityTone(priority: number): Priority {
  if (priority >= 80) return 'High';
  if (priority >= 50) return 'Medium';
  return 'Low';
}

function App() {
  const [activeNav, setActiveNav] = useState('Dashboard');
  const [complaints, setComplaints] = useState<Complaint[]>(initialComplaints);
  const [selectedId, setSelectedId] = useState('#CF-1042');
  const [filter, setFilter] = useState<'All' | Priority>('All');
  const [showReport, setShowReport] = useState(false);
  const [showTracker, setShowTracker] = useState(false);
  const [search, setSearch] = useState('');
  const [trackingId, setTrackingId] = useState('');
  const [trackResult, setTrackResult] = useState<Complaint | null>(null);

  const visibleComplaints = useMemo(() => complaints.filter((complaint) => {
    const matchesFilter = filter === 'All' || priorityTone(complaint.priority) === filter;
    const haystack = `${complaint.id} ${complaint.title} ${complaint.location}`.toLowerCase();
    return matchesFilter && haystack.includes(search.toLowerCase());
  }), [complaints, filter, search]);

  const openIncidents = complaints.filter((complaint) => complaint.status !== 'Resolved').length + 122;
  const criticalAlerts = complaints.filter((complaint) => complaint.priority >= 80 && complaint.status !== 'Resolved').length + 12;
  const selected = complaints.find((complaint) => complaint.id === selectedId) ?? complaints[0];

  function updateStatus(id: string, status: Status) {
    setComplaints((current) => current.map((complaint) => complaint.id === id ? { ...complaint, status } : complaint));
  }

  function handleTrack(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const result = complaints.find((complaint) => complaint.id.toLowerCase() === trackingId.trim().toLowerCase());
    setTrackResult(result ?? null);
  }

  function handleCreateComplaint(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const category = form.get('category') as Category;
    const title = category === 'Roads' ? 'Road hazard' : `${category} issue`;
    const nextId = `#CF-${1043 + complaints.length - initialComplaints.length}`;
    const nextComplaint: Complaint = {
      id: nextId,
      title,
      category,
      location: String(form.get('location') || 'New report'),
      priority: category === 'Roads' || category === 'Water' ? 84 : 58,
      status: 'Submitted',
      created: 'Now',
      reports: 1,
      position: { top: '48%', left: '52%' },
    };
    setComplaints((current) => [nextComplaint, ...current]);
    setSelectedId(nextId);
    setShowReport(false);
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><ShieldCheck size={21} /></div>
          <div><strong>CivicFix</strong><span>AI</span><small>SMART CITY OPS</small></div>
        </div>
        <div className="sidebar-label">WORKSPACE</div>
        <nav className="main-nav">
          {navItems.map((item) => <button className={activeNav === item ? 'nav-item active' : 'nav-item'} key={item} onClick={() => setActiveNav(item)}><span className="nav-icon">{item === 'Dashboard' ? <Radio size={17} /> : item === 'City Map' ? <MapPin size={17} /> : item === 'Reports' ? <FileText size={17} /> : item === 'Analytics' ? <TrendingUp size={17} /> : <AlertTriangle size={17} />}</span>{item}{item === 'Incidents' && <b>128</b>}</button>)}
        </nav>
        <div className="sidebar-bottom">
          <div className="system-status"><span className="live-dot" /> All systems operational</div>
          <button className="nav-item"><Settings size={17} /> Settings</button>
          <div className="profile"><div className="avatar">SJ</div><div><strong>Sarah Johnson</strong><span>City Operations Admin</span></div><MoreHorizontal size={18} /></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button className="mobile-menu"><Menu size={20} /></button>
          <div className="breadcrumb"><span>COMMAND CENTER</span><ChevronDown size={13} /><strong>{activeNav}</strong></div>
          <div className="top-actions"><div className="global-search"><Search size={16} /><input placeholder="Search incidents..." value={search} onChange={(event) => setSearch(event.target.value)} /></div><button className="icon-button"><Bell size={18} /><i /></button><div className="top-date">OCT 26, 2026 <span>15:42 PDT</span></div></div>
        </header>

        {activeNav === 'Dashboard' ? <>
        <section className="page-heading"><div><div className="eyebrow"><span className="live-dot" /> LIVE OPERATIONS FEED</div><h1>City Incident <em>Command Center</em></h1><p>Real-time civic intelligence for a cleaner, safer city.</p></div><div className="heading-actions"><button className="secondary-button" onClick={() => setShowTracker(true)}><Search size={16} /> Track a report</button><button className="primary-button" onClick={() => setShowReport(true)}><Plus size={17} /> New complaint</button></div></section>

        <section className="stats-grid">
          <StatCard label="Open incidents" value={String(openIncidents)} change="+5.2%" icon={<AlertTriangle size={17} />} tone="cyan" detail="vs. last 24 hours" />
          <StatCard label="Critical alerts" value={String(criticalAlerts)} change="+2" icon={<Zap size={17} />} tone="red" detail="need attention" />
          <StatCard label="Resolved today" value="37" change="+12.4%" icon={<Check size={17} />} tone="green" detail="vs. last 24 hours" />
          <StatCard label="Avg. resolution" value="4.2h" change="−8.1%" icon={<Clock3 size={17} />} tone="amber" detail="faster than target" />
        </section>

        <div className="workspace-grid">
          <section className="map-panel panel">
            <div className="panel-heading"><div><div className="panel-kicker"><span className="pulse" /> LIVE CITY MAP</div><h2>Incident density overview</h2></div><div className="map-tools"><button><Layers3 size={15} /> Layers</button><button><Filter size={15} /> Filter <ChevronDown size={13} /></button></div></div>
            <div className="map-canvas">
              <div className="map-noise" />
              <div className="road road-one" /><div className="road road-two" /><div className="road road-three" /><div className="road road-four" /><div className="road road-five" /><div className="district district-one">NORTH DISTRICT</div><div className="district district-two">CENTRAL CORE</div><div className="district district-three">RIVER WARD</div>
              {complaints.map((complaint) => <button key={complaint.id} className={`map-pin ${priorityTone(complaint.priority).toLowerCase()} ${selectedId === complaint.id ? 'selected' : ''}`} style={{ top: complaint.position.top, left: complaint.position.left }} onClick={() => setSelectedId(complaint.id)} aria-label={`View ${complaint.id}`}><span /><label>{selectedId === complaint.id ? complaint.id : ''}</label></button>)}
              <div className="map-zoom"><button>+</button><button>−</button></div><div className="map-legend"><span><i className="high" /> High</span><span><i className="medium" /> Medium</span><span><i className="low" /> Low</span></div><div className="map-coords">40.7128° N&nbsp;&nbsp; 74.0060° W <span>ZOOM 13</span></div>
            </div>
            <div className="map-footer"><span><Crosshair size={14} /> Updated 12 seconds ago</span><span><Navigation size={14} /> 84 active signals</span><button onClick={() => setActiveNav('City Map')}>Open full map <ArrowUpRight size={14} /></button></div>
          </section>

          <aside className="incident-panel panel">
            <div className="panel-heading incident-heading"><div><div className="panel-kicker"><span className="pulse red-pulse" /> PRIORITY QUEUE</div><h2>Active incidents <span>{visibleComplaints.length}</span></h2></div><button className="more-button"><MoreHorizontal size={18} /></button></div>
            <div className="queue-filters"><button className={filter === 'All' ? 'active' : ''} onClick={() => setFilter('All')}>All <b>{complaints.length}</b></button><button className={filter === 'High' ? 'active high-text' : ''} onClick={() => setFilter('High')}>Critical <b>{complaints.filter((item) => item.priority >= 80).length}</b></button><button className={filter === 'Medium' ? 'active amber-text' : ''} onClick={() => setFilter('Medium')}>Monitor</button></div>
            <div className="incident-list">{visibleComplaints.map((complaint, index) => <IncidentCard key={complaint.id} complaint={complaint} index={index} selected={selectedId === complaint.id} onSelect={() => setSelectedId(complaint.id)} onStatusChange={updateStatus} />)}{visibleComplaints.length === 0 && <div className="empty-state">No incidents match your search.</div>}</div>
            <button className="view-all" onClick={() => { setFilter('All'); setSearch(''); }}>View all incidents <ArrowUpRight size={14} /></button>
          </aside>
        </div>

        <section className="bottom-grid"><div className="signal-strip panel"><div><div className="panel-kicker">AI SIGNALS</div><h2>Intelligence at a glance</h2></div><div className="signal-items"><div><Sparkles size={16} /><span>Duplicate detection</span><b>94.8%</b></div><div><TrendingUp size={16} /><span>Priority accuracy</span><b>91.2%</b></div><div><Clock3 size={16} /><span>Avg. response</span><b>18 min</b></div></div></div><div className="selected-card panel"><div className="selected-label">SELECTED INCIDENT</div><div className="selected-row"><div className={`priority-bar ${priorityTone(selected.priority).toLowerCase()}`} /><div><strong>{selected.id} · {selected.title}</strong><span><MapPin size={13} /> {selected.location} · {selected.category}</span></div><div className="selected-score"><b>{selected.priority}</b><span>PRIORITY SCORE</span></div></div></div></section>
        </> : <WorkspaceView activeNav={activeNav} complaints={complaints} visibleComplaints={visibleComplaints} selectedId={selectedId} setSelectedId={setSelectedId} updateStatus={updateStatus} />}
      </main>

      {showReport && <ReportModal onClose={() => setShowReport(false)} onSubmit={handleCreateComplaint} />}
      {showTracker && <TrackerModal onClose={() => { setShowTracker(false); setTrackResult(null); setTrackingId(''); }} trackingId={trackingId} setTrackingId={setTrackingId} onSubmit={handleTrack} result={trackResult} />}
    </div>
  );
}

function WorkspaceView({ activeNav, complaints, visibleComplaints, selectedId, setSelectedId, updateStatus }: { activeNav: string; complaints: Complaint[]; visibleComplaints: Complaint[]; selectedId: string; setSelectedId: (id: string) => void; updateStatus: (id: string, status: Status) => void }) {
  if (activeNav === 'Incidents') return <section className="workspace-view"><WorkspaceHeader eyebrow="INCIDENT OPERATIONS" title="Incident queue" description="Review, assign and resolve every civic signal in one place." action="Export queue" /><div className="workspace-toolbar panel"><div className="toolbar-summary"><strong>{complaints.length + 122}</strong><span>total active signals</span></div><div className="toolbar-summary"><strong>{complaints.filter((item) => item.priority >= 80).length + 12}</strong><span>critical attention</span></div><div className="toolbar-summary"><strong>{complaints.filter((item) => item.status === 'In Progress').length + 28}</strong><span>in progress</span></div></div><div className="full-incident-grid">{visibleComplaints.map((complaint, index) => <IncidentCard key={complaint.id} complaint={complaint} index={index} selected={selectedId === complaint.id} onSelect={() => setSelectedId(complaint.id)} onStatusChange={updateStatus} />)}</div></section>;
  if (activeNav === 'Reports') return <section className="workspace-view"><WorkspaceHeader eyebrow="CITIZEN REPORTS" title="Report intelligence" description="Understand what residents are experiencing across the city." action="Download report" /><div className="report-grid"><div className="report-feature panel"><div className="panel-heading"><div><div className="panel-kicker">TOP ISSUE CATEGORIES</div><h2>What citizens are reporting</h2></div><TrendingUp size={17} color="#4bd9d1" /></div>{(['Roads', 'Waste', 'Lighting', 'Water', 'Drainage'] as Category[]).map((category, index) => { const count = complaints.filter((item) => item.category === category).length + [34, 22, 18, 14, 9][index]; return <div className="category-row" key={category}><span>{category}</span><div className="category-bar"><i style={{ width: `${Math.min(count * 2, 94)}%` }} /></div><b>{count}</b></div>; })}</div><div className="report-feature panel"><div className="panel-heading"><div><div className="panel-kicker">AI QUALITY CHECK</div><h2>Signal confidence</h2></div><Sparkles size={17} color="#4bd9d1" /></div><div className="confidence-score">94.8<span>%</span></div><p>of incoming reports are automatically categorized with high confidence.</p><div className="confidence-list"><span><Check size={14} /> Category detected</span><span><Check size={14} /> Duplicate scan complete</span><span><Check size={14} /> Location verified</span></div></div></div><div className="reports-table panel"><div className="panel-heading"><div><div className="panel-kicker">LATEST SUBMISSIONS</div><h2>Citizen report activity</h2></div><FileText size={17} color="#7c98a4" /></div>{complaints.slice(0, 5).map((complaint) => <div className="report-row" key={complaint.id}><span className="report-id">{complaint.id}</span><strong>{complaint.title}</strong><span>{complaint.location}</span><span className={`table-status ${complaint.status.toLowerCase().replace(' ', '-')}`}>{complaint.status}</span><b>{complaint.priority}</b></div>)}</div></section>;
  if (activeNav === 'Analytics') return <section className="workspace-view"><WorkspaceHeader eyebrow="CITY ANALYTICS" title="Performance analytics" description="A clear view of response speed, resolution quality and city health." action="Compare periods" /><div className="analytics-grid"><div className="analytics-hero panel"><div className="panel-heading"><div><div className="panel-kicker">RESOLUTION VELOCITY</div><h2>Incidents resolved over time</h2></div><span className="analytics-period">LAST 30 DAYS <ChevronDown size={13} /></span></div><div className="chart"><div className="chart-labels"><span>120</span><span>80</span><span>40</span><span>0</span></div><div className="chart-lines"><i /><i /><i /><i /><svg viewBox="0 0 600 180" preserveAspectRatio="none"><polyline points="0,142 75,126 140,136 205,92 275,108 350,71 425,87 500,44 600,57" /></svg></div><div className="chart-days"><span>OCT 01</span><span>OCT 08</span><span>OCT 15</span><span>OCT 22</span><span>TODAY</span></div></div></div><div className="analytics-side panel"><div className="panel-kicker">SERVICE LEVEL</div><div className="donut"><strong>86<span>%</span></strong><small>within target</small></div><div className="service-row"><span><i className="high" /> High priority</span><b>3.8h</b></div><div className="service-row"><span><i className="medium" /> Medium priority</span><b>7.2h</b></div><div className="service-row"><span><i className="low" /> Low priority</span><b>14.5h</b></div></div></div><div className="insight-banner panel"><Sparkles size={17} /><div><strong>AI insight</strong><span>Road hazards in Central Core are being reported 28% more often than this time last month.</span></div><ArrowUpRight size={16} /></div></section>;
  return <section className="workspace-view"><WorkspaceHeader eyebrow="CITY OPERATIONS MAP" title="Full city map" description="Explore priority signals by neighborhood and response zone." action="Center on city" /><div className="full-map-panel panel"><div className="map-canvas full-map-canvas"><div className="map-noise" /><div className="road road-one" /><div className="road road-two" /><div className="road road-three" /><div className="road road-four" /><div className="road road-five" /><div className="district district-one">NORTH DISTRICT</div><div className="district district-two">CENTRAL CORE</div><div className="district district-three">RIVER WARD</div>{complaints.map((complaint) => <button key={complaint.id} className={`map-pin ${priorityTone(complaint.priority).toLowerCase()} ${selectedId === complaint.id ? 'selected' : ''}`} style={{ top: complaint.position.top, left: complaint.position.left }} onClick={() => setSelectedId(complaint.id)} aria-label={`View ${complaint.id}`}><span /><label>{selectedId === complaint.id ? complaint.id : ''}</label></button>)}<div className="map-zoom"><button>+</button><button>−</button></div><div className="map-legend"><span><i className="high" /> High</span><span><i className="medium" /> Medium</span><span><i className="low" /> Low</span></div></div></div><div className="map-summary-row"><div className="panel"><strong>{complaints.length + 84}</strong><span>active map signals</span></div><div className="panel"><strong>12</strong><span>response zones</span></div><div className="panel"><strong>3</strong><span>high-risk clusters</span></div></div></section>;
}

function WorkspaceHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action: string }) {
  return <div className="workspace-header"><div><div className="eyebrow"><span className="live-dot" /> {eyebrow}</div><h1>{title}</h1><p>{description}</p></div><button className="secondary-button"><ArrowUpRight size={15} /> {action}</button></div>;
}

function StatCard({ label, value, change, icon, tone, detail }: { label: string; value: string; change: string; icon: React.ReactNode; tone: string; detail: string }) {
  return <div className={`stat-card ${tone}`}><div className="stat-top"><span>{label}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong><div className="stat-bottom"><span className="change">{change}</span><span>{detail}</span></div><div className="sparkline"><i /><i /><i /><i /><i /><i /></div></div>;
}

function IncidentCard({ complaint, index, selected, onSelect, onStatusChange }: { complaint: Complaint; index: number; selected: boolean; onSelect: () => void; onStatusChange: (id: string, status: Status) => void }) {
  const tone = priorityTone(complaint.priority).toLowerCase();
  return <article className={`incident-card ${tone} ${selected ? 'selected' : ''}`} onClick={onSelect}><div className="incident-accent" /><div className="incident-top"><span className="incident-index">0{index + 1} · {complaint.id}</span><span className="incident-time">{complaint.created}</span></div><h3>{complaint.title} <span>·</span> {complaint.location}</h3><div className="incident-meta"><span className={`status-dot ${tone}`} /> <select value={complaint.status} onClick={(event) => event.stopPropagation()} onChange={(event) => onStatusChange(complaint.id, event.target.value as Status)}><option>Submitted</option><option>In Progress</option><option>Resolved</option></select><span className="report-count"><Layers3 size={12} /> {complaint.reports} reports</span><b className="priority-score">{complaint.priority}<small> PTS</small></b></div><div className="incident-progress"><span style={{ width: `${complaint.priority}%` }} /></div></article>;
}

function ReportModal({ onClose, onSubmit }: { onClose: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  const [preview, setPreview] = useState<string | null>(null);
  function handleFile(event: ChangeEvent<HTMLInputElement>) { const file = event.target.files?.[0]; if (file) setPreview(URL.createObjectURL(file)); }
  return <div className="modal-backdrop"><div className="modal"><div className="modal-header"><div><div className="eyebrow"><Sparkles size={13} /> SMART REPORTING</div><h2>Report a civic issue</h2><p>Our AI will analyze the details and prioritize your report.</p></div><button className="close-button" onClick={onClose}><X size={19} /></button></div><form onSubmit={onSubmit}><label className="upload-zone">{preview ? <img src={preview} alt="Selected report" /> : <><ImagePlus size={25} /><strong>Add a photo</strong><span>Help our AI identify the issue faster</span></>}<input type="file" accept="image/*" onChange={handleFile} /></label><div className="form-grid"><label>Issue category<select name="category" defaultValue="Roads">{categories.map((category) => <option key={category}>{category}</option>)}</select></label><label>Location<input required name="location" placeholder="e.g. MG Road, near Central Station" /></label></div><label>What did you notice?<textarea name="description" placeholder="Describe the issue briefly..." rows={3} /></label><div className="ai-preview"><Sparkles size={16} /><div><strong>AI analysis ready</strong><span>Category, duplicate reports and urgency will be detected automatically.</span></div></div><button className="primary-button full" type="submit"><Send size={16} /> Submit for AI analysis</button></form></div></div>;
}

function TrackerModal({ onClose, trackingId, setTrackingId, onSubmit, result }: { onClose: () => void; trackingId: string; setTrackingId: (value: string) => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void; result: Complaint | null }) {
  return <div className="modal-backdrop"><div className="modal tracker-modal"><div className="modal-header"><div><div className="eyebrow"><Search size={13} /> CITIZEN PORTAL</div><h2>Track your report</h2><p>Enter your CivicFix tracking ID to see the latest status.</p></div><button className="close-button" onClick={onClose}><X size={19} /></button></div><form onSubmit={onSubmit}><label>Tracking ID<div className="tracking-input"><span>#</span><input required value={trackingId.replace('#', '')} onChange={(event) => setTrackingId(`#${event.target.value}`)} placeholder="CF-1042" /></div></label><button className="primary-button full" type="submit"><Search size={16} /> Find report</button></form>{result && <div className="track-result"><div className="result-header"><div><span className="result-id">{result.id}</span><h3>{result.title}</h3></div><span className={`status-pill ${result.status.toLowerCase().replace(' ', '-')}`}><span /> {result.status}</span></div><p><MapPin size={14} /> {result.location}</p><div className="status-steps"><span className="done"><Check size={13} /> Submitted</span><span className={result.status !== 'Submitted' ? 'done' : ''}><Clock3 size={13} /> In Progress</span><span className={result.status === 'Resolved' ? 'done' : ''}><ShieldCheck size={13} /> Resolved</span></div></div>}{trackingId && !result && <div className="not-found"><CircleHelp size={17} /> We couldn't find that report. Try <strong>#CF-1042</strong>.</div>}</div></div>;
}

export default App;
